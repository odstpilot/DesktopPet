

Info:


This is a EXE(or JRE if u want that insted) that puts a pet on your screen to walk across, over the coming weeks i wll add more features, so keep checking the website: projects.definitlynotablog.com
For now the pet has three funcions he can perform: spit out pictures you upload, spit out notepad files you upload...and the ability to make fart noises while doing the previous two.
He will preform one of these functions every 30 seconds to a minute(working on making this time editable), if no actions are selcted he will just keep walking.  

           How to upload your own pet:
      1. get photos of your pet moving up, down, left, and right.
      2. go into the coresponding folder delete the files photos there and upload your own...its that simple(your welcome)
      ***warning*** make sure you upload the same amount of photos in each file, so if you put 4 photos of your pet moving left, put in 4 of him moving right, if you dont the animation 
         engine i made will break, i dont know what will hapen in that case, but i dont wana find out.

     How to upload your own imgs/notes for him to spit out:
     
      1. go into the coresponding folder, replace the img/notes
   


  ***warning*** DO NOT CHANGE THE NAME OF ANY OF THE FOLDERS(or the m.wav(you can change the m.wav file if u want a diffrent sound, just make sure its the same name))